class Feed {
  final String nickname;
  final String? thumbnail;
  final String content;
  final DateTime createdAt;
  List<String> imageSrcs; // 이미지 URL 목록으로 변경

  Feed({
    required this.nickname,
    this.thumbnail,
    required this.content,
    required this.createdAt,
    required this.imageSrcs, // List<String> 타입으로 수정
  });

  factory Feed.fromJson(Map<String, dynamic> json) {
    // 이미지 URL 목록을 추출하고, 없는 경우 빈 리스트를 할당
    List<String> imageUrls = [];
    if (json['feedImages'] != null && json['feedImages'].isNotEmpty) {
      imageUrls =
          json['feedImages'].map<String>((img) => img['imageSrc']).toList();
    }

    return Feed(
      nickname: json['user']['nickname'],
      thumbnail: json['user']['thumbnail'],
      content: json['content'],
      createdAt: DateTime.parse(json['createdAt']),
      imageSrcs: imageUrls,
    );
  }
}
