import 'dart:io';
import 'package:calendar/api/create_post_service.dart';
import 'package:calendar/models/post.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class CreateFeedPage extends StatefulWidget {
  final String groupEventId;

  const CreateFeedPage({super.key, required this.groupEventId});

  @override
  _CreateFeedPageState createState() => _CreateFeedPageState();
}

class _CreateFeedPageState extends State<CreateFeedPage> {
  final TextEditingController _contentController = TextEditingController();
  final FeedService createfeed = FeedService();
  List<File> _selectedImages = [];
  final picker = ImagePicker();
  bool _isLoading = false;

  Future<void> _pickImage() async {
    final pickedFiles = await picker.pickMultiImage();
    if (pickedFiles != null) {
      List<File> newImages =
          pickedFiles.map((pickedFile) => File(pickedFile.path)).toList();
      if (newImages.length > 5) {
        newImages = newImages.sublist(0, 5); // 최대 5개 이미지만 선택
      }
      setState(() {
        _selectedImages = newImages;
      });
    }
  }

  Future<void> _submitFeed() async {
    if (_isLoading) return;
    if (_contentController.text.isEmpty || _selectedImages.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('내용과 이미지를 입력해주세요.')));
      return;
    }
    setState(() => _isLoading = true);

    Feed? newFeed = await createfeed.createFeedWithImages(
        _contentController.text, widget.groupEventId, _selectedImages);

    setState(() => _isLoading = false);
    if (newFeed != null) {
      Navigator.pop(context, newFeed); // 생성된 피드 객체를 결과로 전달
    } else {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('피드 작성 실패')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('새 피드 작성')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            GestureDetector(
              onTap: _pickImage,
              child: Container(
                height: 200,
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: _selectedImages.isEmpty
                    ? Icon(Icons.add_a_photo, size: 48, color: Colors.white70)
                    : Image.file(_selectedImages.first, fit: BoxFit.cover),
              ),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _contentController,
              decoration: const InputDecoration(
                hintText: '내용을 입력하세요',
                border: OutlineInputBorder(),
              ),
              maxLines: 5,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _submitFeed,
              child: _isLoading
                  ? const CircularProgressIndicator()
                  : const Text('피드 작성'),
            ),
          ],
        ),
      ),
    );
  }
}
